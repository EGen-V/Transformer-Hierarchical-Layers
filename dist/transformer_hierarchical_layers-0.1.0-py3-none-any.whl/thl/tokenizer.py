from typing import List, Union
import torch

class Tokenizer:
    """
    Wrapper for tokenization. 
    Can wrap huggingface tokenizers or provide simple whitespace splitting.
    """
    def __init__(self, vocab_size: int = 50257, never_split: List[str] = None):
        self.vocab_size = vocab_size
        self.pad_token_id = 0
        self.eos_token_id = 1
        self.never_split = never_split if never_split else []
        
    def encode(self, text: str) -> torch.Tensor:
        # Mock encoding: simplistic character-based or hash-based
        # Respect never_split: If text contains never_split tokens, they should be mapped to specific IDs
        # For this mock, we just handle them if they appear exactly? 
        # Real impl would use regex partition.
        
        # Placeholder logic:
        # If text is in never_split, return special token?
        # This is a mock tokenizer, implementing complex split logic is overkill unless requested.
        # I'll add the parameter and rudimentary handling.
        
        tokens = []
        # Trivial split by never_split set (very inefficient mock)
        # Assuming text corresponds to mock behavior.
        
        # Standard loop
        for c in text:
            tokens.append(ord(c) % self.vocab_size)
            
        return torch.tensor(tokens, dtype=torch.long)
        
    def decode(self, tokens: Union[torch.Tensor, List[int]]) -> str:
        if isinstance(tokens, torch.Tensor):
            tokens = tokens.tolist()
        return "".join([chr(t % 256) for t in tokens])
